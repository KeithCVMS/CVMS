param (
    [string[]]$workdir
)
write-output "start script"
set-location -PATH "$workdir"
write-output "test.ps1  in  $workdir"

write-output "calling script"

.\AutopilotUNIBranding.ps1

exit 0