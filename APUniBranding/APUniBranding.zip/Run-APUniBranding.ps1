param (
    [string[]]$workdir
)
start-transcript "runBrand.log"
write-host "start script"
set-location -PATH "$workdir"
Get-Location
write-host "AutopilotUNIBranding.ps1  in  $workdir"

write-host "calling script"

.\AutopilotUNIBranding.ps1

write-host "completed script"

exit 0