param (
    [string[]]$workdir
)
start-transcript "runBrand.log"
write-host "start script"
set-location -PATH "$workdir"
Get-Location
write-host ""
write-host "AutopilotUNIBranding.ps1  in  $workdir"

write-host "calling script"
write-host ""

. .\AutopilotUNIBranding.ps1

write-host "completed script"

exit 0