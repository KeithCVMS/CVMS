Put your CAB files here.  They are typically named like this:

Microsoft-Windows-Client-Language-Pack_x64_es-es.cab