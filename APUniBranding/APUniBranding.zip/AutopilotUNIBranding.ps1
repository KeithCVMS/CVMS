<#PSScriptInfo
.VERSION 3.3.1
.GUID 39efc9c5-7b51-4d1f-b650-0f3818e5327a
.AUTHOR Michael Niehaus
.COMPANYNAME
.COPYRIGHT Copyright (c) 2025 Michael Niehaus
.TAGS intune endpoint autopilot branding windows
.LICENSEURI https://github.com/mtniehaus/AutopilotBranding/blob/main/LICENSE
.PROJECTURI https://github.com/mtniehaus/AutopilotBranding
.ICONURI
.EXTERNALMODULEDEPENDENCIES
.REQUIREDSCRIPTS
.EXTERNALSCRIPTDEPENDENCIES
.RELEASENOTES
v1.0.0 - 2019-04-16 - Created initial version as an MSI
v1.0.1 - 2019-04-18 - Added additional features for languages and features on demand
v2.0.0 - 2020-05-18 - Converted from an MSI to a Win32 app
v2.0.1 - 2020-05-26 - Added logic to remove the Edge desktop icon
v2.0.2 - 2020-08-11 - Added time zone logic
v2.0.3 - 2023-09-24 - Improved start layout support for Windows 11
v2.0.4 - 2024-01-31 - Improved logging
v2.0.5 - 2024-06-01 - Added logic to hide "Learn about this picture" and related Spotlight stuff
v2.0.6 - 2024-08-15 - Added logic to update OneDrive with the machine-wide installer
v2.0.7 - 2024-09-14 - Added logic to install the Microsoft.Windows.Sense.Client (for MDE) if it was missing
v2.0.8 - 2024-12-27 - Updated for Windows 11 taskbar, added support for removing/disabling Windows features
v3.0.0 - 2025-04-17 - Lots of improvements and additions based on feedback
v3.0.1 - 2025-04-18 - Fixed OneDriveSetup bugs
v3.0.2 - 2025-04-19 - Added a -Force option when installing the Update-InboxApp script; added -AllUsers when removing provisioned in-box apps
v3.0.3 - 2025-05-02 - Additional fixes based on user feedback; tweaked script formatting; added FSIA, desktop switch logic
v3.0.4 - 2025-05-02 - Fixed FSIA default (should be 0)
v3.0.5 - 2025-05-14 - Remove logic that removed widgets, cross-device app.
v3.1.0 - 2025-06-01 - Modified WinGet logic, switched to PowerShell for creating package
v3.2.0 - 2025-07-15 - Various fixes (start menu layout, apps, etc.)
v3.2.1 - 2025-07-15 - Updated makeapps.cmd to use PowerShell 7
v3.3.0 - 2025-09-20 - Added bookmark cleanup for Edge, Chrome. Fixed start menu config. Added Try/catch/finally. Added OOBE check.
v3.3.1 - 2025-10-10 - Minor bug fixes

#KH local changes for directories, business unit and logging format
#>

[CmdletBinding()]
param (
	[Parameter(Mandatory = $false)] [Switch] $Force
)

# If we are running as a 32-bit process on an x64 system, re-launch as a 64-bit process
if ("$env:PROCESSOR_ARCHITEW6432" -ne "ARM64") {
	if (Test-Path "$($env:WINDIR)\SysNative\WindowsPowerShell\v1.0\powershell.exe") {
		& "$($env:WINDIR)\SysNative\WindowsPowerShell\v1.0\powershell.exe" -ExecutionPolicy bypass -NoProfile -File "$PSCommandPath"
		Exit $lastexitcode
	}
}
#Custom CVM Code
	#Set TimeZone in case it has been changed
	invoke-expression (Invoke-WebRequest -Uri "https://raw.githubusercontent.com/KeithCVMS/CVMS/main/scripts/SetTimeZone.ps1" -UseBasicParsing).Content  
	#Enhanced Logging function
	invoke-expression (Invoke-WebRequest -Uri "https://raw.githubusercontent.com/KeithCVMS/CVMS/main/scripts/Log.ps1" -UseBasicParsing).Content  

	# Create output folder

	$InstallRoot = "$($env:ProgramData)\CVMMPA"
	if (-not (Test-Path "$InstallRoot")) {
		Mkdir "$InstallRoot" -Force
	}

	# Start logging
	Start-Transcript "$InstallRoot\AutopilotUNIBranding.log"

	Log ""
	Log "*****************************************************************"
	Log "*                    AutopilotUNIBranding                       *"
	Log "*                      Force: $Force                            *"
	Log "*****************************************************************"
	Log ""
	
	# Creating tag file
	Set-Content -Path "$InstallRoot\AutopilotUNIBranding.tag" -Value "Start Install $(get-date -f ""yyyy/MM/dd hh:mm:ss tt"") $($(Get-TimeZone).Id)"

	# Custom CVM Code section
	Log "***************************************"
	Log "Capture local configuration and OS information"
	#Capture organization from GrpTag.xml so that script can make CVM/MPA decisions
	[xml]$GrpTag = Get-Content "$InstallRoot\GrpTag.xml" 
	Log "DevDomain:$($GrpTag.grpTag.DevDomain)"
	Log "DevGvmt:$($GrpTag.grpTag.DevGvmt)"
	Log "DevRole:$($GrpTag.grptag.DevRole)"
	Log "DomRole:$($GrpTag.grpTag.DevDomain)$($GrpTag.grpTag.DevRole)"
	$UserDomain = $($GrpTag.grpTag.DevDomain)
	$UserRole = $($GrpTag.grptag.DevRole)
	$UserDomRole = $userDomain + $UserRole
	Log "UserDomain:$UserDomain"
	Log "UserRole:$UserRole"
	Log "UserDomRole:$UserDomRole"
	Log ""

	# Capture OsVersion information
	$ci = Get-Computerinfo
	$bldnum = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion').currentbuildnumber
	$bldubr = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion').ubr
	$dispver = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion').displayversion

	Log "OSversion:$($ci.OsName)"
	Log "OSBuild: $dispver - $bldnum.$bldubr"
	Log ""
#End Custom Code

function Check-NuGetProvider {
	[CmdletBinding()]
	param (
		[version]$MinimumVersion = [version]'2.8.5.201'
	)
	$provider = Get-PackageProvider -Name NuGet -ListAvailable -ErrorAction SilentlyContinue |
	Sort-Object Version -Descending |
	Select-Object -First 1

	if (-not $provider) {
		Log 'NuGet Provider Package not detected, installing...'
		Install-PackageProvider -Name NuGet -Force | Out-Null
	} elseif ($provider.Version -lt $MinimumVersion) {
		Log "NuGet provider v$($provider.Version) is less than required v$MinimumVersion; updating."
		Install-PackageProvider -Name NuGet -Force | Out-Null
        
	} else {
		Log "NuGet provider meets min requirements (v:$($provider.Version))."
	}
    
}

# Get the Current start time in UTC format, so that Time Zone Changes don't affect total runtime calculation
$startUtc = [datetime]::UtcNow

# Don't show progress bar for Add-AppxPackage - there's a weird issue where the progress stays on the screen after the apps are installed
$OriginalProgressPreference = $ProgressPreference
$ProgressPreference = 'SilentlyContinue'

# STEP 0: Bail out if we aren't in OOBE
$TypeDef = @"
using System;
using System.Text;
using System.Collections.Generic;
using System.Runtime.InteropServices;
 
namespace Api
{
 public class Kernel32
 {
   [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
   public static extern int OOBEComplete(ref int bIsOOBEComplete);
 }
}
"@
Add-Type -TypeDefinition $TypeDef -Language CSharp
$IsOOBEComplete = $false
$null = [Api.Kernel32]::OOBEComplete([ref] $IsOOBEComplete)
if ($IsOOBEComplete) {
	if (-not $Force)
	{
		Log "OOBE is completed, bailing out without doing any configuration."
  		Stop-Transcript
		exit 0
	} else {
		Log "OOBE is completed but -Force specified, will run anyway."
	}
}

try 
{
	Log "*******************************************************************"
	Log "*                   Start the real work"
	Log "*******************************************************************"
	Log ""
	# PREP: Load the Config.xml
	$installFolder = "$PSScriptRoot\"
	Log "Install folder: $installFolder"
	Log "Loading configuration: $($installFolder)$($UserDomain)Config.xml"
	[Xml]$config = Get-Content "$($installFolder)$($UserDomain)Config.xml"

	# PREP: Load the default user registry
	reg.exe load HKLM\TempUser "C:\Users\Default\NTUSER.DAT" | Out-Null

	# STEP 1: Apply a custom start menu and taskbar layout
	Log "Customize Start Menu"

	if ($ci.OsBuildNumber -lt 22000) {		#Win10 OS StartMenu......OSBuildNumber 22000 was the first Win11 build so all lower build were Win10 or earlier versions of windows
		if ($config.Config.SkipStartLayout -ine "true") {
			Log "Importing layout: $($installFolder)Layout.xml"
			Copy-Item "$($installFolder)Layout.xml" "C:\Users\Default\AppData\Local\Microsoft\Windows\Shell\LayoutModification.xml" -Force
		} else {
			Log "Skipping Start layout (Windows 10)"
		}
	} else { 	#Win11 OS StartMenu
		if ($config.Config.SkipStartLayout -ine "true") {
			Log "Copying Start menu layout: $($installFolder)$($UserDomRole)Start2.bin"
			MkDir -Path "C:\Users\Default\AppData\Local\Packages\Microsoft.Windows.StartMenuExperienceHost_cw5n1h2txyewy\LocalState" -Force -ErrorAction SilentlyContinue | Out-Null
			Copy-Item "$($installFolder)$($UserDomRole)Start2.bin" "C:\Users\Default\AppData\Local\Packages\Microsoft.Windows.StartMenuExperienceHost_cw5n1h2txyewy\LocalState\Start2.bin" -Force
			Log "Copying Start menu settings: $($installFolder)$($UserDomRole)settings.dat"
			MkDir -Path "C:\Users\Default\AppData\Local\Packages\Microsoft.Windows.StartMenuExperienceHost_cw5n1h2txyewy\Settings" -Force -ErrorAction SilentlyContinue | Out-Null
			Copy-Item "$($installFolder)$($UserDomRole)settings.dat" "C:\Users\Default\AppData\Local\Packages\Microsoft.Windows.StartMenuExperienceHost_cw5n1h2txyewy\Settings\settings.dat" -Force
		} else {
			Log "Skipping Start layout (Windows 11)"
		}

		if ($config.Config.SkipTaskbarLayout -ine "true") {
			Log "Importing Taskbar layout: $($installFolder)$($UserDomRole)TaskbarLayoutModification.xml"
			MkDir -Path "C:\Windows\OEM\" -Force -ErrorAction SilentlyContinue | Out-Null
			Copy-Item "$($installFolder)$($UserDomRole)TaskbarLayoutModification.xml" "C:\Windows\OEM\TaskbarLayoutModification.xml" -Force
			Log "adding layoutxmlpath registry for OEM\TaskbarLayoutModification.xml"
			& reg.exe add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer" /v LayoutXMLPath /t REG_EXPAND_SZ /d "%SystemRoot%\OEM\TaskbarLayoutModification.xml" /f /reg:64 2>&1 | Out-Null
			Log "Unpin the Microsoft Store app from the taskbar"
			& reg.exe add "HKLM\TempUser\Software\Policies\Microsoft\Windows\Explorer" /v NoPinningStoreToTaskbar /t REG_DWORD /d 1 /f /reg:64 2>&1 | Out-Null
		} else {
			Log "Skipping Taskbar layout (Windows 11)"
		}
	}

	# STEP 2: Configure background
	if ($config.Config.SkipTheme -ine "true") {
		Log "Setting up Autopilot theme"
		Mkdir "C:\Windows\Resources\OEM Themes" -Force | Out-Null
		Copy-Item "$installFolder\Autopilot.theme" "C:\Windows\Resources\OEM Themes\Autopilot.theme" -Force
		Mkdir "C:\Windows\web\wallpaper\Autopilot" -Force | Out-Null
		Copy-Item "$installFolder\Autopilot.jpg" "C:\Windows\web\wallpaper\Autopilot\Autopilot.jpg" -Force
		Log "Setting Autopilot theme as the new user default"
		& reg.exe add "HKLM\TempUser\SOFTWARE\Microsoft\Windows\CurrentVersion\Themes" /v InstallTheme /t REG_EXPAND_SZ /d "%SystemRoot%\resources\OEM Themes\Autopilot.theme" /f /reg:64 2>&1 | Out-Null
		& reg.exe add "HKLM\TempUser\SOFTWARE\Microsoft\Windows\CurrentVersion\Themes" /v CurrentTheme /t REG_EXPAND_SZ /d "%SystemRoot%\resources\OEM Themes\Autopilot.theme" /f /reg:64 2>&1 | Out-Null
	} else {
		Log "Skipping Autopilot theme"
		Log "Setting Win11 standard ThemeC as the new user default"
		reg.exe add "HKLM\TempUser\SOFTWARE\Microsoft\Windows\CurrentVersion\Themes" /v InstallTheme /t REG_EXPAND_SZ /d "%SystemRoot%\resources\Themes\themeC.theme" /f | Out-Host
	}

	# STEP 2A: Set lock screen image, see https://www.systemcenterdudes.com/apply-custom-lock-screen-wallpaper-using-intune/
	if ($config.Config.SkipLockScreen -ine "true") {
		Log "Configuring lock screen image"
		$RegPath = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\PersonalizationCSP"
		Mkdir "C:\Windows\web\wallpaper\Autopilot" -Force | Out-Null
		$LockScreenImage = "C:\Windows\web\wallpaper\Autopilot\AutopilotLock.jpg"
		Copy-Item "$installFolder\AutopilotLock.jpg" $LockScreenImage -Force
		if (!(Test-Path -Path $RegPath)) {
			New-Item -Path $RegPath -Force | Out-Null
		}
		New-ItemProperty -Path $RegPath -Name LockScreenImagePath -Value $LockScreenImage -PropertyType String -Force | Out-Null
		New-ItemProperty -Path $RegPath -Name LockScreenImageUrl -Value $LockScreenImage -PropertyType String -Force | Out-Null
		New-ItemProperty -Path $RegPath -Name LockScreenImageStatus -Value 1 -PropertyType DWORD -Force | Out-Null
	} else {
		Log "Skipping lock screen image"
	}

	# STEP 2B: Stop Start menu from opening on first logon
	Log "Stop Start Menu on first logon"
	& reg.exe add "HKLM\TempUser\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v StartShownOnUpgrade /t REG_DWORD /d 1 /f /reg:64 2>&1 | Out-Null

	# STEP 2C: Hide "Learn more about this picture" from the desktop (so wallpaper will work)
	Log "Hide Learn more about this picture"
	& reg.exe add "HKLM\TempUser\Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel" /v "{2cc5ca98-6485-489a-920e-b3e88a6ccce3}" /t REG_DWORD /d 1 /f /reg:64 2>&1 | Out-Null

	# STEP 2D: Disable Windows Spotlight as per https://github.com/mtniehaus/AutopilotBranding/issues/13#issuecomment-2449224828 (so wallpaper will work)
	Log "Disabling Windows Spotlight for Desktop"
	& reg.exe add "HKLM\TempUser\Software\Policies\Microsoft\Windows\CloudContent" /v DisableSpotlightCollectionOnDesktop /t REG_DWORD /d 1 /f /reg:64 2>&1 | Out-Null

	# STEP 3: Left Align Start Button in the default user profile, users can change it if they want
	if ($config.Config.SkipLeftAlignStart -ine "true") {
		Log "Configuring left aligned Start menu"
		& reg.exe add "HKLM\TempUser\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v TaskbarAl /t REG_DWORD /d 0 /f /reg:64 2>&1 | Out-Null
	} else {
		Log "Skipping Left align start"
	}

	# STEP 4: Hide the widgets
	if ($config.Config.SkipHideWidgets -ine "true") {
		# This will fail on Windows 11 24H2 due to UCPD, see https://kolbi.cz/blog/2024/04/03/userchoice-protection-driver-ucpd-sys/
		# New Work Around tested with 24H2 to disable widgets as a preference
		try {
			Log "Attempting to Hide widgets via Reg Key"	
			$output = & reg.exe add "HKLM\TempUser\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v TaskbarDa /t REG_DWORD /d 0 /f /reg:64 2>&1
			#write-host $output
			if($LASTEXITCODE -ne 0) {
			throw $output
			}
			Log "Widgets Hidden Completed"
		}
		catch {
			$errorMessage = $_.Exception.Message
			#Write-Host "This is the error: $errorMessage"
			if ($errorMessage -like '*Access is denied*') {
			Log "UCPD driver may active"
			Log "Attempting Widget Hiding workaround (TaskbarDa)"
			$regExePath = (Get-Command reg.exe).Source
			$tempRegExe = "$($env:TEMP)\reg1.exe"
			Copy-Item -Path $regExePath -Destination $tempRegExe -Force -ErrorAction Stop
			& $tempRegExe add "HKLM\TempUser\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v TaskbarDa /t REG_DWORD /d 0 /f /reg:64 2>&1 | Out-Null
			Remove-Item $tempRegExe -Force -ErrorAction SilentlyContinue
			Log "Widget Workaround Completed"
			}
		}
	} else {
		Log "Skipping Hide widgets"
	}

	# STEP 4A: Disable Widgets (Grey out Settings Toggle)
	if ($config.Config.SkipDisableWidgets -ine "true") {

		# GPO settings below will completely disable Widgets, see:https://learn.microsoft.com/en-us/windows/client-management/mdm/policy-csp-newsandinterests#allownewsandinterests
		Log "Disabling Widgets"
		if (-not (Test-Path "HKLM:\Software\Policies\Microsoft\Dsh")) {
			New-Item -Path "HKLM:\Software\Policies\Microsoft\Dsh" | Out-Null
		}
		Set-ItemProperty -Path "HKLM:\Software\Policies\Microsoft\Dsh"  -Name "DisableWidgetsOnLockScreen" -Value 1
		Set-ItemProperty -Path "HKLM:\Software\Policies\Microsoft\Dsh"  -Name "DisableWidgetsBoard" -Value 1
		Set-ItemProperty -Path "HKLM:\Software\Policies\Microsoft\Dsh"  -Name "AllowNewsAndInterests" -Value 0

	}

	# STEP 5: Set time zone (if specified)
	if ($config.Config.TimeZone) {
		Log "Setting time zone: $($config.Config.TimeZone)"
		Set-Timezone -Id $config.Config.TimeZone
	} else {
		# Enable location services so the time zone will be set automatically (even when skipping the privacy page in OOBE) when an administrator signs in
		Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\location" -Name "Value" -Type "String" -Value "Allow" -Force
		Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Sensor\Overrides\{BFA794E4-F964-4FDB-90F6-51056BFE4B44}" -Name "SensorPermissionState" -Type "DWord" -Value 1 -Force
		Start-Service -Name "lfsvc" -ErrorAction SilentlyContinue
	}

	# STEP 6: Remove specified provisioned apps if they exist
	Log "Removing specified in-box provisioned apps"
	$apps = Get-AppxProvisionedPackage -online
	$config.Config.RemoveApps.App | ForEach-Object {
		$current = $_
		$apps | Where-Object { $_.DisplayName -eq $current } | ForEach-Object {
			try {
				Log "Removing provisioned app: $current"
				$_ | Remove-AppxProvisionedPackage -Online -AllUsers -ErrorAction SilentlyContinue | Out-Null
			}
			catch { }
		}
	}

	# STEP 6A: Prevent Copilot PWA from being installed
	if ($config.Config.SkipRemoveCopilotPWA -ine "true") {
		Log "Removing specified in-box provisioned apps"
		reg.exe add "HKLM\TempUser\Software\Microsoft\Windows\CurrentVersion\Explorer\AutoInstalledPWAs" /v CopilotPWAPreinstallCompleted /t REG_DWORD /d 1 /f /reg:64
	}

	# STEP 7: Install OneDrive per machine
	if ($config.Config.OneDriveSetup) {
	
		$dest = "$($env:TEMP)\OneDriveSetup.exe"
		$client = new-object System.Net.WebClient
		if ($env:PROCESSOR_ARCHITECTURE -eq "ARM64") {
			$url = $config.Config.OneDriveARMSetup
		} else {
			$url = $config.Config.OneDriveSetup
		}
		Log "Downloading OneDriveSetup: $url"
		# this while loop inserted to allow for unstable internet connection failing the Download
		while($attempt -le 5) {
			Log "Download Attempt: $attempt"
			if (test-path -path $dest) {remove-item -path $dest}
			try {
				$client.DownloadFile($url, $dest)
				Log "Download Complete"
				break
			}
			Catch {
				Log "Download failed - retry"
				$attempt++
				start-sleep 10
			}
		}
		Log "Installing: $dest"
		$proc = Start-Process $dest -ArgumentList "/allusers /silent" -WindowStyle Hidden -PassThru
		$proc.WaitForExit()
		Log "OneDriveSetup exit code: $($proc.ExitCode)"

		Log "Making sure the Run key exists"
		& reg.exe add "HKLM\TempUser\Software\Microsoft\Windows\CurrentVersion\Run" /f /reg:64 2>&1 | Out-Null
		& reg.exe query "HKLM\TempUser\Software\Microsoft\Windows\CurrentVersion\Run" /reg:64 2>&1 | Out-Null
		Log "Changing OneDriveSetup value to point to the machine wide EXE"
		# Quotes are so problematic, we'll use the more risky approach and hope garbage collection cleans it up later
		Set-ItemProperty -Path "HKLM:\TempUser\Software\Microsoft\Windows\CurrentVersion\Run" -Name OneDriveSetup -Value """C:\Program Files\Microsoft OneDrive\Onedrive.exe"" /background" | Out-Null
	}

	# STEP 8: Don't let Edge create a desktop shortcut (roams to OneDrive, creates mess)
	Log "Turning off (old) Edge desktop shortcut"
	& reg.exe add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer" /v DisableEdgeDesktopShortcutCreation /t REG_DWORD /d 1 /f /reg:64 2>&1 | Out-Null
	Log "Turning off Edge desktop icon"
	& reg.exe add "HKLM\SOFTWARE\Policies\Microsoft\EdgeUpdate" /v "CreateDesktopShortcutDefault" /t REG_DWORD /d 0 /f /reg:64 2>&1 | Out-Null
	& reg.exe add "HKLM\SOFTWARE\Policies\Microsoft\EdgeUpdate" /v "RemoveDesktopShortcutDefault" /t REG_DWORD /d 2 /f /reg:64 2>&1 | Out-Null
	if (Test-Path "C:\Users\Public\Desktop\Microsoft Edge.lnk") {
		Log "Removing Edge desktop shortcut"
		Remove-Item "C:\Users\Public\Desktop\Microsoft Edge.lnk" -Force
	}

	# STEP 8A: Attempt to Donwload and install Latest Edge for Business MSI from Evergreen URL
	if ($config.Config.SkipEdgeUpdate -ine "true") {
		
		$client = new-object System.Net.WebClient
		$dest = "$($env:TEMP)\MicrosoftEdgeEnterpriseX64.msi"
		$url = $config.Config.EdgeBusinessMSI
		Log "Downloading Latest Edge for Business: $url"
		$client.DownloadFile($url, $dest)
		
		# Edge Version is buried in Comments of MSI. Parse the first 13 charaters to pull out Version number.
		$shell = New-Object -ComObject Shell.Application
		$folder = $shell.NameSpace((Split-Path $dest))
		$file = $folder.ParseName((Split-Path $dest -Leaf))
		$comment = $folder.GetDetailsOf($file, 24) # 24 is the index for comments
		$versionOnly = $comment.Substring(0, [Math]::Min(13, $comment.Length))

		Log "Installing Edge for Business V:$versionOnly"
		$arguments = "/i `"$($dest)`" /qn /L*v $($env:TEMP)\EdgeBusiness.log"
		#$arguments = "/i `"$($dest)`""
		$proc = Start-Process -FilePath "msiexec.exe" -ArgumentList $arguments -PassThru -WindowStyle Hidden
		$proc.WaitForExit()
		if ($proc.ExitCode -ne 0) {
			#Write-Error "Installation failed (exit code $($proc.ExitCode))"
			Log "MSI Error, trying to Run MicrosoftEdgeUpdate.exe instead"
			$proc = Start-Process -FilePath "C:\Program Files (x86)\Microsoft\EdgeUpdate\MicrosoftEdgeUpdate.exe" -argumentlist "/silent /install appguid={56EB18F8-B008-4CBD-B6D2-8C97FE7E9062}&appname=Microsoft%20Edge&needsadmin=True" -PassThru -WindowStyle Hidden
			$proc.WaitForExit()
			Log "Edge Updater Triggered" 
		} else {
			Log "Edge for Business Updated"
		}

	}

	# STEP 8B: Clean up any OEM-added bookmarks from the default user profile
	$bookmarks = "C:\Users\Default\AppData\Local\Microsoft\Edge\User Data\Default\Bookmarks"
	if (Test-Path $bookmarks) {
		Log "Removing Edge bookmarks folder from default profile"
		Remove-Item $bookmarks -Force
	}

	# STEP 9: Add language packs
	if (Test-Path "$($installFolder)LPs") {
		Get-ChildItem "$($installFolder)LPs" -Filter *.cab | ForEach-Object {
			Log "Adding language pack: $($_.FullName)"
			Add-WindowsPackage -Online -NoRestart -PackagePath $_.FullName
		}
	}

	# STEP 10: Change language
	if ($config.Config.Language) {
		Log "Configuring language using: $($config.Config.Language)"
		& $env:SystemRoot\System32\control.exe "intl.cpl,,/f:`"$($installFolder)$($config.Config.Language)`""
	}

	# STEP 11: Add features on demand, Disable Optional Features, Remove Windows Capabilities
	$currentWU = (Get-ItemProperty -Path "HKLM:\Software\Policies\Microsoft\Windows\WindowsUpdate\AU" -ErrorAction Ignore).UseWuServer
	if ($currentWU -eq 1) {
		Log "Turning off WSUS"
		Set-ItemProperty -Path "HKLM:\Software\Policies\Microsoft\Windows\WindowsUpdate\AU"  -Name "UseWuServer" -Value 0
		Restart-Service wuauserv
	}

	# Step 11A: Disable Optional features
	if ($config.Config.DisableOptionalFeatures.Feature.Count -gt 0) {
		try {
			$EnabledOptionalFeatures = Get-WindowsOptionalFeature -Online | Where-Object { $_.State -eq "Enabled" }
			foreach ($EnabledFeature in $EnabledOptionalFeatures) {
				if ($config.Config.DisableOptionalFeatures.Feature -contains $EnabledFeature.FeatureName) {
					Log "Disabling Optional Feature:  $($EnabledFeature.FeatureName)"
					try {
						Disable-WindowsOptionalFeature -Online -FeatureName $EnabledFeature.FeatureName -NoRestart | Out-Null
					}
					catch {}
				}
			}
			}
		catch {
			Log "Unexpected error querying Windows optional features: $_"
		}
	}

	# Step 11B: Remove Windows Capabilities
	if ($config.Config.RemoveCapability.Capability.Count -gt 0) {
		try {
			$InstalledCapabilities = Get-WindowsCapability -Online | Where-Object { $_.State -eq "Installed" }
			foreach ($InstalledCapability in $InstalledCapabilities) {
				if ($config.Config.RemoveCapability.Capability -contains $InstalledCapability.Name.Split("~")[0]) {
					Log "Removing Windows Capability:  $($InstalledCapability.Name)"
					try {
						Remove-WindowsCapability -Online -Name $InstalledCapability.Name  | Out-Null
					}
					catch {
						Log "  Unable to remove Windows capability: $_"
					}
				}
			}
		} catch {
			Log "Unexpected error querying Windows capabilities: $_"
		}
	}

	# Step 11C: Add features on demand
	if ($config.Config.AddFeatures.Feature.Count -gt 0) {
		$config.Config.AddFeatures.Feature | ForEach-Object {
			Log "Adding Windows feature: $_"
			try {
				$result = Add-WindowsCapability -Online -Name $_
				if ($result.RestartNeeded) {
					Log "  Feature $_ was installed but requires a restart"
				}
			}
			catch {
				Log "  Unable to add Windows capability: $_"
			}
		}
	}

	if ($currentWU -eq 1) {
		Log "Turning on WSUS"
		Set-ItemProperty -Path "HKLM:\Software\Policies\Microsoft\Windows\WindowsUpdate\AU"  -Name "UseWuServer" -Value 1
		Restart-Service wuauserv
	}

	# STEP 12: Customize default apps
	if ($config.Config.DefaultApps) {
		Log "Setting default apps: $($config.Config.DefaultApps)"
		& Dism.exe /Online /Import-DefaultAppAssociations:`"$($installFolder)$($config.Config.DefaultApps)`"
	}

	# STEP 13: Set registered user and organization
	if ($config.Config.RegisteredOwner) {
		Log "Configuring registered user information"
		& reg.exe add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion" /v RegisteredOwner /t REG_SZ /d "$($config.Config.RegisteredOwner)" /f /reg:64 2>&1 | Out-Null
		& reg.exe add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion" /v RegisteredOrganization /t REG_SZ /d "$($config.Config.RegisteredOrganization)" /f /reg:64 2>&1 | Out-Null
	}

	# STEP 14: Configure OEM branding info
	if ($config.Config.OEMInfo) {
		Log "Configuring OEM branding info"

		& reg.exe add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\OEMInformation" /v Manufacturer /t REG_SZ /d "$($config.Config.OEMInfo.Manufacturer)" /f /reg:64 2>&1 | Out-Null
		& reg.exe add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\OEMInformation" /v Model /t REG_SZ /d "$($config.Config.OEMInfo.Model)" /f /reg:64 2>&1 | Out-Null
		& reg.exe add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\OEMInformation" /v SupportPhone /t REG_SZ /d "$($config.Config.OEMInfo.SupportPhone)" /f /reg:64 2>&1 | Out-Null
		& reg.exe add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\OEMInformation" /v SupportHours /t REG_SZ /d "$($config.Config.OEMInfo.SupportHours)" /f /reg:64 2>&1 | Out-Null
		& reg.exe add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\OEMInformation" /v SupportURL /t REG_SZ /d "$($config.Config.OEMInfo.SupportURL)" /f /reg:64 2>&1 | Out-Null
		Copy-Item "$installFolder\$($config.Config.OEMInfo.Logo)" "C:\Windows\$($config.Config.OEMInfo.Logo)" -Force
		& reg.exe add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\OEMInformation" /v Logo /t REG_SZ /d "C:\Windows\$($config.Config.OEMInfo.Logo)" /f /reg:64 2>&1 | Out-Null
	}

	# STEP 15A: Force Enterprise SKU
	if ($config.Config.SkipEnterpriseGVLK -ine "true") {
		Log "Forcing Enterprise SKU"
		& changepk.exe /ProductKey NPPR9-FWDCX-D2C8J-H872K-2YT43
	}

	# STEP 15B: Enable UE-V
	if ($config.Config.SkipUEV -ine "true") {
		Log "Enabling UE-V"
		Enable-UEV
		Set-UevConfiguration -Computer -SettingsStoragePath "%OneDriveCommercial%\UEV" -SyncMethod External -DisableWaitForSyncOnLogon
		Get-ChildItem "$($installFolder)UEV" -Filter *.xml | ForEach-Object {
			Log "Registering template: $($_.FullName)"
			Register-UevTemplate -Path $_.FullName
		}
	} else {
		Log "Skipping UE-V"
	}

	# STEP 16: Disable network location fly-out
	Log "Turning off network location fly-out"
	& reg.exe add "HKLM\SYSTEM\CurrentControlSet\Control\Network\NewNetworkWindowOff" /f /reg:64 | Out-Null

	# STEP 17: Remove the registry keys for Dev Home and Outlook New
	# This is a workaround for the issue where the Dev Home and Outlook New apps are installed by default
	if ($config.Config.SkipAutoinstallingApps -ine "true") {
		Log "Disabling Windows 11 Dev Home and Outlook New"
		$DevHome = "HKLM:\SOFTWARE\Microsoft\WindowsUpdate\Orchestrator\UScheduler_Oobe\DevHomeUpdate"
		$OutlookNew = "HKLM:\SOFTWARE\Microsoft\WindowsUpdate\Orchestrator\UScheduler_Oobe\OutlookUpdate"
		if (Test-Path -Path $DevHome) {
			Log "  Removing DevHome key"
			Remove-Item -Path $DevHome -Force
		}
		if (Test-Path -Path $OutlookNew) {
			Log "  Removing Outlook for Windows key"
			Remove-Item -Path $OutlookNew -Force
		}
	} else {
		Log "Skipping autoinstalling app logic"
	}

	# STEP 18: WinGet installs
	if ($config.Config.SkipWinGet -ne 'true') {
		# Ensure NuGet provider before installing modules
		Check-NuGetProvider 

		#Log 'Installing WinGet.Client module'
		Install-Module -Name Microsoft.WinGet.Client -Force -Scope AllUsers -Repository PSGallery | Out-Null
		Log 'Installing Lastest Winget package and dependencies'
		Repair-WinGetPackageManager -Force -Latest | Out-Null  #-Allusers not supported in System Context so was removed.
		
		#Permalink for latest supported x64 version of vc_redist.x64
		$VCppRedistributable_Url = "https://aka.ms/vs/17/release/vc_redist.x64.exe"
		#set temporary install file path
		$VCppRedistributable_Path = Join-Path $env:TEMP 'vc_redist.x64.exe'
		
		Invoke-WebRequest -uri $VCppRedistributable_Url -outfile $VCppRedistributable_Path -UseBasicParsing
		Start-Process -FilePath $VCppRedistributable_Path -ArgumentList "/install", "/quiet", "/norestart" -Wait
		
		#$wingetExe = (Get-ChildItem -Path 'C:\Program Files\WindowsApps' -Recurse -Filter 'winget.exe' -ErrorAction SilentlyContinue).FullName
		#Look for Winget.exe in the C:\Program Files\WindowsApps\Microsoft.DesktopAppInstaller_* Folder
		$WinGetResolve = Resolve-Path "C:\Program Files\WindowsApps\Microsoft.DesktopAppInstaller_*__8wekyb3d8bbwe\winget.exe"
		$wingetExe = $WinGetResolve[-1].Path
		$wingetVer = & "$wingetExe" --version
		Log "Winget version is: $wingetVer"
		
		#Cleanup VCredistrib setup file
		Remove-Item $VCppRedistributable_Path -Force
		
		foreach ($id in $config.Config.WinGetInstall.Id) {
			Log "WinGet installing: $id"
			try {
				& "$wingetExe" install $id --silent --scope machine --accept-package-agreements --accept-source-agreements
			}
			catch {
				Log "WinGet installing error: $_"
			}
		}
		
	} else {
		Log 'Skipping WinGet installs'
	}

	# STEP 18A: Configure Chrome initial preferences (needs to happen after Chrome is installed but before a user logs in)
	# See https://www.chromium.org/administrators/configuring-other-preferences/ for available preferences that can be set.
	if ($config.Config.SkipChromeConfig -ine "true") {
		Log "Copying Chrome initial_preferences file"
		$dest = "C:\Program Files\Google\Chrome\Application"
		if (-not (Test-Path $dest))
		{
			MkDir $dest -Force | Out-Null
		}
		Copy-Item "$PSScriptRoot\initial_preferences" "$dest\" -Force
		if (Test-Path "C:\Users\Public\Desktop\Google Chrome.lnk") {
			Log "Removing Chrome desktop shortcut"
			Remove-Item "C:\Users\Public\Desktop\Google Chrome.lnk" -Force
		}
	}

	# STEP 19: Disable extra APv2 pages (too late to do anything about the EULA), see https://call4cloud.nl/autopilot-device-preparation-hide-privacy-settings/
	if ($config.Config.SkipAPv2 -ine "true") {
		$registryPath = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\OOBE"
		New-ItemProperty -Path $registryPath -Name "DisablePrivacyExperience" -Value 1 -PropertyType DWord -Force | Out-Null
		New-ItemProperty -Path $registryPath -Name "DisableVoice" -Value 1 -PropertyType DWord -Force | Out-Null
		New-ItemProperty -Path $registryPath -Name "PrivacyConsentStatus" -Value 1 -PropertyType DWord -Force | Out-Null
		New-ItemProperty -Path $registryPath -Name "ProtectYourPC" -Value 3 -PropertyType DWord -Force | Out-Null
		Log 'APv2 extra pages disabled'
	} else {
		Log 'Skipping APv2 tweaks'
	}

	# STEP 20: Updates & Inbox-App script
	if ($config.Config.SkipUpdates -ne 'true') {
		try {

			#Nuget v 2.8.5.201 is required to import mtniehaus's PS Gallery Script Update-InboxApp
			$minrequired = [version]'2.8.5.201'
			Check-NuGetProvider -MinimumVersion $minrequired
		} catch {
			Log "Error updating NuGet"
		}
		try {
			Log 'Installing Update-InboxApp script'
			Install-Script Update-InboxApp -Force | Out-Null

			Log 'Updating inbox apps'
			# The path might not be set right to find this, so we'll hard-code the location
			Get-AppxPackage -AllUsers | Select-Object -Unique PackageFamilyName | . "C:\Program Files\WindowsPowerShell\Scripts\Update-InboxApp.ps1" -Verbose
		} catch {
			Log "Error updating in-box apps: $_"
		}
		try {
			Log 'Triggering Windows Update scan'
			$ns = 'Root\cimv2\mdm\dmmap'
			$class = 'MDM_EnterpriseModernAppManagement_AppManagement01'
			$result = Get-CimInstance -Namespace $ns -ClassName $class | Invoke-CimMethod -MethodName UpdateScanMethod
			# Inspect the return code
			if ($result.ReturnValue -ne 0) {
				Log "***** Windows MDM UpdateScanMethod failed with code $($result.ReturnValue) *****"
				# Handle gracefully instead of exiting
			} else {
				Log "UpdateScanMethod succeeded"
			}
		} catch {
			Log "Error triggering Windows Update scan: $_"
		}
	} else {
		Log 'Skipping updates'
	}

	# STEP 21: Skip FSIA and turn off delayed desktop switch
	if ($config.Config.SkipShowDesktopFaster -ine "true") {
		$registryPath = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System"
		New-ItemProperty -Path $registryPath -Name "EnableFirstLogonAnimation" -Value 0 -PropertyType DWord -Force | Out-Null
		New-ItemProperty -Path $registryPath -Name "DelayedDesktopSwitchTimeout" -Value 0 -PropertyType DWord -Force | Out-Null
	}
} catch {
	Log "Unhandled exception: $_"
} finally {
	log "CLEANUP: Unload default user registry"
	[GC]::Collect()
	reg.exe unload HKLM\TempUser | Out-Null
	log "done cleanup"
}


# Calculate the total run time
$stopUtc = [datetime]::UtcNow
$runTime = $stopUTC - $startUTC
# Format the runtime with hours, minutes, and seconds
$runTimeFormatted = 'Duration: {0:hh} hr {0:mm} min {0:ss} sec' -f $runTime

# Format the runtime with hours, minutes, and seconds
#if ($runTime.TotalHours -ge 1) {
#	$runTimeFormatted = 'Duration: {0:hh} hr {0:mm} min {0:ss} sec' -f $runTime
#
#else {
#	$runTimeFormatted = 'Duration: {0:mm} min {0:ss} sec' -f $runTime
#}

Log "************************************************"
Log "*    Autopilot Branding Complete"
Log "*   Total Script Time: $($runTimeFormatted)"
Log "************************************************"

$ProgressPreference = $OriginalProgressPreference 

Add-Content -Path "$InstallRoot\AutopilotUNIBranding.tag" -Value "Complete Install $(get-date -f ""yyyy/MM/dd hh:mm:ss tt"") $($(Get-TimeZone).Id)"

Stop-Transcript

exit 0