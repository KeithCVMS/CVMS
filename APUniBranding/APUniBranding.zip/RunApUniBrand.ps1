if ("$env:PROCESSOR_ARCHITEW6432" -ne "ARM64") {
	if (Test-Path "$($env:WINDIR)\SysNative\WindowsPowerShell\v1.0\powershell.exe") {
		& "$($env:WINDIR)\SysNative\WindowsPowerShell\v1.0\powershell.exe" -ExecutionPolicy bypass -NoProfile -File "$PSCommandPath" -Reboot $Reboot -RebootTimeout $RebootTimeout
		Exit $lastexitcode
	}
}

#Set TimeZone in case it has been changed
invoke-expression (Invoke-WebRequest -Uri "https://raw.githubusercontent.com/KeithCVMS/CVMS/main/scripts/SetTimeZone.ps1" -UseBasicParsing).Content  
#Enhanced Logging function
invoke-expression (Invoke-WebRequest -Uri "https://raw.githubusercontent.com/KeithCVMS/CVMS/main/scripts/Log.ps1" -UseBasicParsing).Content  

#Check for Root folder
$RootFolder = "$($Env:Programdata)\CVMMPA"
If (!(Test-Path $RootFolder)) {
		New-Item -Path "$RootFolder" -ItemType Directory
	Log "The folder $RootFolder was successfully created."
}

$PLSQFolder = "$RootFolder\"
If (!(Test-Path $PLSQFolder)) {
	New-Item -Path "$PLSQFolder" -ItemType Directory
	Log "The folder $PLSQFolder was successfully created."
}

#Create App and Main Log Folder
#This uses a "tag" file to determine whether the script has been run previously
#The "tag" file also provides a quick way to manually or from Intune to check for its presence on a System
#It can be used in a similar method as the detection mechanism for Win32apps in Intune
#This section EXITS if the script has been previouly run in a preprov environment 

$RunTag = "$RootFolder\AutoPilotUniBrand.tag"

If (Test-Path $RunTag) {
	Log "Script has already been run. Exiting"
	Add-Content -Path "$RunTag" -Value "Script has already been run- $(get-date) - Exiting"
	Exit 0
}
Else {
	Set-Content -Path "$RunTag" -Value "Start Script $(get-date)"
}

Start-Transcript -Path "$RootFolder\AutoPilotUniBrand.log"
Log ""
Log "******************************************************************************"
Log "                     AutoPilotUniBrand Platform Script"
Log "******************************************************************************"
Log ""
Log ""
Log "******************************************************************************"
Log ""


#Run AutoPilotBranding to finish update config
Log ""
Log "Initiating APUniBranding"

$APUniBrndFldr = "$RootFolder\APUniBrand"
If (!(Test-Path $APUniBrndFldr)) {
	New-Item -Path "$APUniBrndFldr" -ItemType Directory
	Log "The folder $APUniBrndFldr was successfully created."
}

$templateFilePath = "$APUniBrndFldr\APUniBranding.zip"

Log "Loading UpdateOS script"

Invoke-WebRequest `
-Uri "https://raw.githubusercontent.com/KeithCVMS/CVMS/main/APUniBranding/APUniBranding.zip" `
-OutFile $templateFilePath `
-UseBasicParsing `
-Headers @{"Cache-Control"="no-cache"}

Expand-Archive $templateFilePath -DestinationPath $APUniBrndFldr -Force

$ProgFilePath = "$APUniBrndFldr\AutoPilotUNIBranding.ps1"
$ArgList = "-command $ProgFilePath "
Log "ProgFilePath: $ProgFilePath"
log "ArgList: $ArgList"
log "APUniBrndFldr: $APUniBrndFldr"

# if ($Verbose) {
	# Log "Calling APUniBranding script verbose"
	# start-process -FilePath "$PSHOME\powershell.exe" -ArgumentList "$arglist" -Wait -WorkingDirectory "$APUniBrndFldr"
	# Log "finished APUniBranding script verbose"
# } Else {
	Log "Calling APUniBranding script hidden"
	start-process -FilePath "$PSHOME\powershell.exe" -ArgumentList "$arglist" -Wait -WorkingDirectory "$APUniBrndFldr" -WindowStyle Hidden
	Log "finished APUniBranding script hidden"
# }

Log "APUniBranding Complete"
Log ""

Log "****************************************"
Log "RunAPUNIBrand complete"
Log "*****************************************"

Stop-Transcript
exit 0